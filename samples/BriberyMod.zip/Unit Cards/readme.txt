ROME TOTAL ZOR - Unit_Info cards

Optional additional graphics files for Rome Total ZOR

v. WGAFF Date 28/03/05
compatible with Rome Total ZOR v. WGAFF

readme v1 28/03/05

Caveat
These additional files are intended only for users who already have experience in modifying their games. 

Summary
This download includes the larger unit_info cards that correspond to the unit cards included Rome Total ZOR. They have been included separately as they are not necessary to use the modification and are several times larger than the rest of the files put together.

In addition to this readme, rtz_info.zip should contain the following files:

all_units_info folder - this folder contains graphics for all the unit_info cards relevant to the Rome Total ZOR mod 


Detailed Install Instructions
1) Download rtz_info.zip
2) Activating unit cards:
If you have not unpacked your .pak files do this, if you have go to step 2b).
2a)
- In your /Rome - Total War/Data/ folder create a new folder called UI
- within this UI folder create another new folder called units_info
- within this units folder create twenty new folders named after each faction as follows:
- 	ARMENIA
- 	BRITONS
- 	CARTHAGE
- 	DACIA
- 	EGYPT
- 	GAULS
- 	GERMAN
- 	GREEK_CITIES
- 	MACEDON
- 	NUMIDIA
- 	PARTHIA
- 	PONTUS
- 	ROMANS_BRUTII
- 	ROMANS_JULII
- 	ROMANS_SCIPII
- 	ROMANS_SENATE
- 	SCYTHIA
- 	SELEUCID
- 	SPAIN
- 	THRACE
- Copy the files from rtz_info.zip's all_unit_info folder into each one of these faction folders.
2b)
	If you have already unpacked your .pak files then the above folders should already exist.
-	Ensure that they are in /Rome - Total War/Data/UI/units_info (and not /Rome - Total War/Data/Packs/Data/UI/units_info).
-	Copy all of the files from rtz.zip_info's all_unit_info folder into each one of the faction folders. IMPORTANT when it asks you if you wish to overwrite the existing files, click 'NO' to each of them. If you click yes then some of that faction's 'vanilla' units may appear with the wrong unit cards.
