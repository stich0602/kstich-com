Reason For Creation:
I know that many times throughout my RTW experiences that I have wanted to make my enemy's armies go away through bribing them, but I also wanted more.
I wanted the enemy units to join my faction and shove them back im my enemy's faces. With this mod, it is finally possible!
With help of Epistolary Richard over at totalwar.org I have been able to adjust the RTW files to allow you to actually purchase the enemy armies.

Purpose:
The purpose of this Rome: Total War modification is to allow the player to actually purchase the enemy units in a bribe.
You will find that this mod adds a completely new aspect to the game, it will allow you to turn an enemy army upon its once leader.
The peasants have been left alone, so you will NOT be able to gain peasant units if you bribe them.

Known Problems:
Missing skins or sprites -
Many of the changes in descr_model_battle involved telling the game which texture and sprite to look at for each model for each faction.
This has not had to be done for every model (thankfully) but from my experience, it's a little fickle sometimes. If textures or sprites fail to appear, the model is white or suddenly disappears at a certain distance, some success has been achieved by defining the texture/sprite for every faction.
Be wary of knock-on effects though as many models are used across different factions.
This modification will allow you to make all of the R:TW units in a custom battle. It will also make it so that the unit selection screen is broken for each faction in custom battles.

Files:
This zip file contains four things:
This README.TXT file, the 'export_descr_unit.txt' file, the 'descr_model_battle.txt' file and 'Unit Cards' folder.

** Please note that this modification changes critical game files, and all files that it replaces should be backed-up before installation. **

To install:
1. Copy export_descr_unit.txt and paste it over the one in your Rome directory.
2. Copy descr_model_battle.txt and paste it over the one in your Rome directory.
3. Create a folder in your rome directory entitled 'UI'.
4. Create 20 (twenty) folders inside your 'UI' folder.
5. Rename one of the folders for each of the following factions:
	ARMENIA
	BRITONS
	CARTHAGE
	DACIA
	EGYPT
	GAULS
	GERMAN
	GREEK_CITIES
	MACEDON
	NUMIDIA
	PARTHIA
	PONTUS
	ROMANS_BRUTII
	ROMANS_JULII
	ROMANS_SCIPII
	ROMANS_SENATE
	SCYTHIA
	SELEUCID
	SPAIN
	THRACE
6. Copy and paste all of the files in the 'Unit Cards' folder into EVERY one of the folders that you created.

I would like to thank Epistolary Richard for creating the unit cards.
I would also like to thank the Creative Assembly for creating this great game for all of us to play.

Enjoy!
stich0602 3/29/2005


